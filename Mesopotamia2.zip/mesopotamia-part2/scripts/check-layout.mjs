// Memeriksa bahwa tidak ada dua kotak yang tumpang tindih, termasuk jalur gerak elemen bergerak.
// Menulis LAYOUT.md (tabel koordinat x, y, lebar, tinggi). Jalankan: npm run check-layout
import fs from 'node:fs';

const L = JSON.parse(fs.readFileSync('src/layout.json', 'utf8'));
const {w: CW, h: CH} = L.canvas;
const M = L.motion;
const f = L.fixed;

const hit = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
const inCanvas = (a) => a.x >= 0 && a.y >= 0 && a.x + a.w <= CW && a.y + a.h <= CH;

// kotak "jalur gerak" (gabungan semua posisi selama animasi)
const stickPath = {x: f.stickman.x + M.stickmanSlideFromX, y: f.stickman.y - M.stickmanBobPx,
  w: f.stickman.w - M.stickmanSlideFromX, h: f.stickman.h + M.stickmanBobPx};
const s = M.titleStampScale;
const titleStamp = {x: f.title.x - (f.title.w * (s - 1)) / 2, y: f.title.y - (f.title.h * (s - 1)) / 2,
  w: f.title.w * s, h: f.title.h * s};
const labelPath = {x: f.label.x + M.labelSlideFromX, y: f.label.y, w: f.label.w - M.labelSlideFromX, h: f.label.h};

let problems = 0;
const rows = [];
const fmt = (r) => `${Math.round(r.x)} | ${Math.round(r.y)} | ${Math.round(r.w)} | ${Math.round(r.h)}`;

for (let b = 1; b <= 8; b++) {
  const focus = L.focus[String(b)];
  const items = [
    ['judul (maks. saat stempel)', titleStamp, true],
    ['label (jalur geser)', labelPath, false],
    ['stickman (jalur geser + napas)', stickPath, false],
    ['area fokus', focus, true],
    ['subtitle', f.subtitle, true],
  ];
  for (const [n, r, mustFit] of items) {
    rows.push(`| ${b} | ${n} | ${fmt(r)} |`);
    if (mustFit && !inCanvas(r)) { problems++; console.error(`Beat ${b}: ${n} keluar layar`); }
  }
  for (let i = 0; i < items.length; i++)
    for (let j = i + 1; j < items.length; j++)
      if (hit(items[i][1], items[j][1])) {
        problems++;
        console.error(`Beat ${b}: TUMPANG TINDIH ${items[i][0]} x ${items[j][0]}`);
      }
}
// momen transisi: pelat penutup penuh layar berada DI ATAS isi beat dan DI BAWAH subtitle
const full = {x: 0, y: 0, w: CW, h: CH};
const trans = [];
for (let t = 1; t <= 7; t++)
  trans.push(`| ${t}→${t + 1} | pelat transisi (lapisan penutup, 12 frame) | ${fmt(full)} |\n| ${t}→${t + 1} | subtitle (lapisan teratas, tidak ikut ditutup) | ${fmt(f.subtitle)} |`);
trans.push(`| 8 (akhir) | layar hitam 30 frame (lapisan penutup) | ${fmt(full)} |`);

const md = `# Tabel koordinat (kanvas ${CW}×${CH})\n\nSemua nilai piksel eksplisit di src/layout.json.\n\n` +
  `## Per beat\n\n| Beat | Elemen | x | y | lebar | tinggi |\n|---|---|---|---|---|---|\n` +
  rows.map((r) => r.replace(/\| (\d+) \| (.*?) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \|/, '| $1 | $2 | $3 | $4 | $5 | $6 |')).join('\n') +
  `\n\n## Momen transisi\n\n| Transisi | Elemen | x | y | lebar | tinggi |\n|---|---|---|---|---|---|\n` + trans.join('\n') +
  `\n\nHasil pemeriksaan: ${problems === 0 ? 'TIDAK ADA tumpang tindih.' : problems + ' masalah, lihat konsol.'}\n`;
fs.writeFileSync('LAYOUT.md', md);
console.log(problems === 0 ? 'OK: tidak ada kotak yang tumpang tindih. LAYOUT.md ditulis.' : `${problems} masalah`);
process.exit(problems ? 1 : 0);
