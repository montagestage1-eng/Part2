// Membuat src/captions.ts dari public/narasi.srt.
// Tiap cue dibagi per kata, waktu dibagi proporsional dengan jumlah huruf kata di dalam cue itu.
import fs from 'node:fs';

const srt = fs.readFileSync('public/narasi.srt', 'utf8').replace(/\r/g, '');
const toSec = (s) => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

const words = [];
for (const block of srt.trim().split(/\n\s*\n/)) {
  const lines = block.split('\n');
  const ti = lines.findIndex((l) => l.includes('-->'));
  if (ti < 0) continue;
  const [a, b] = lines[ti].split('-->');
  const start = toSec(a);
  const end = toSec(b);
  const ws = lines.slice(ti + 1).join(' ').trim().split(/\s+/).filter(Boolean);
  const weights = ws.map((w) => Math.max(1, w.replace(/[^\p{L}\p{N}]/gu, '').length));
  const total = weights.reduce((x, y) => x + y, 0);
  let cur = start;
  ws.forEach((w, i) => {
    const d = ((end - start) * weights[i]) / total;
    words.push({w, start: +cur.toFixed(3), end: +(cur + d).toFixed(3)});
    cur += d;
  });
}

const body = words
  .map((x) => `  {w: ${JSON.stringify(x.w)}, start: ${x.start}, end: ${x.end}},`)
  .join('\n');
fs.writeFileSync(
  'src/captions.ts',
  `// DIBUAT OTOMATIS oleh scripts/make-captions.mjs dari public/narasi.srt\n` +
    `// Waktu dalam detik (sebelum AUDIO_OFFSET).\n` +
    `export type CaptionWord = {w: string; start: number; end: number};\n\n` +
    `export const CAPTIONS: CaptionWord[] = [\n${body}\n];\n`
);
console.log(`captions.ts: ${words.length} kata, kata terakhir selesai di ${words[words.length - 1].end}s`);
