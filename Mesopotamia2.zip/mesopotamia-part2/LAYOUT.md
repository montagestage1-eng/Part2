# Tabel koordinat (kanvas 1080×1920)

Semua nilai piksel eksplisit di src/layout.json.

## Per beat

| Beat | Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|---|
| 1 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 1 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 1 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 1 | area fokus | 500 | 470 | 520 | 700 |
| 1 | subtitle | 70 | 1560 | 940 | 230 |
| 2 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 2 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 2 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 2 | area fokus | 500 | 560 | 520 | 420 |
| 2 | subtitle | 70 | 1560 | 940 | 230 |
| 3 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 3 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 3 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 3 | area fokus | 500 | 700 | 520 | 520 |
| 3 | subtitle | 70 | 1560 | 940 | 230 |
| 4 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 4 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 4 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 4 | area fokus | 500 | 480 | 520 | 640 |
| 4 | subtitle | 70 | 1560 | 940 | 230 |
| 5 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 5 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 5 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 5 | area fokus | 500 | 470 | 520 | 420 |
| 5 | subtitle | 70 | 1560 | 940 | 230 |
| 6 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 6 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 6 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 6 | area fokus | 500 | 470 | 520 | 720 |
| 6 | subtitle | 70 | 1560 | 940 | 230 |
| 7 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 7 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 7 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 7 | area fokus | 500 | 470 | 520 | 660 |
| 7 | subtitle | 70 | 1560 | 940 | 230 |
| 8 | judul (maks. saat stempel) | 23 | 80 | 1035 | 161 |
| 8 | label (jalur geser) | -470 | 280 | 1000 | 110 |
| 8 | stickman (jalur geser + napas) | -420 | 872 | 900 | 608 |
| 8 | area fokus | 500 | 560 | 520 | 560 |
| 8 | subtitle | 70 | 1560 | 940 | 230 |

## Momen transisi

| Transisi | Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|---|
| 1→2 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 1→2 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 2→3 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 2→3 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 3→4 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 3→4 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 4→5 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 4→5 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 5→6 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 5→6 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 6→7 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 6→7 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 7→8 | pelat transisi (lapisan penutup, 12 frame) | 0 | 0 | 1080 | 1920 |
| 7→8 | subtitle (lapisan teratas, tidak ikut ditutup) | 70 | 1560 | 940 | 230 |
| 8 (akhir) | layar hitam 30 frame (lapisan penutup) | 0 | 0 | 1080 | 1920 |

Hasil pemeriksaan: TIDAK ADA tumpang tindih.
