import React from 'react';
import {Composition} from 'remotion';
import {H, W} from './layout';
import {Main} from './Main';
import {FPS, TOTAL_FRAMES} from './timing';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="MesopotamiaPart2"
      component={Main}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
