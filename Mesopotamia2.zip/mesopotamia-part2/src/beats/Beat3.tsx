import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C} from '../theme';

// Fokus: roda kayu berputar di atas jalan; garis jalan bergeser sesuai putaran roda.
const Wheel: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: frame - 4, fps, config: {damping: 13, stiffness: 120}});
  const angle = interpolate(frame, [8, duration], [0, 600], {
    extrapolateLeft: 'clamp',
    easing: Easing.out(Easing.quad),
  });
  const R = 215;
  const circ = 2 * Math.PI * R;
  const roadShift = (angle / 360) * circ;
  return (
    <svg width={520} height={520} viewBox="0 0 520 520">
      <line x1={0} y1={480} x2={520} y2={480} stroke={C.ink} strokeWidth={8} strokeDasharray="60 40"
        strokeDashoffset={roadShift % 100} />
      <g transform={`translate(260 255) scale(${pop})`}>
        <g transform={`rotate(${angle})`}>
          <circle r={R} fill="none" stroke={C.ink} strokeWidth={46} />
          <circle r={R} fill="none" stroke={C.clayDark} strokeWidth={32} />
          {Array.from({length: 8}, (_, i) => (
            <g key={i} transform={`rotate(${i * 45})`}>
              <line x1={0} y1={0} x2={R - 10} y2={0} stroke={C.ink} strokeWidth={24} strokeLinecap="round" />
              <line x1={0} y1={0} x2={R - 10} y2={0} stroke={C.clayLight} strokeWidth={13} strokeLinecap="round" />
            </g>
          ))}
          <circle r={38} fill={C.gold} stroke={C.ink} strokeWidth={8} />
        </g>
      </g>
    </svg>
  );
};

export const Beat3: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={3}
    duration={duration}
    bg="bg3.jpg"
    cam={{s0: 1.0, s1: 1.3, x0: 0, x1: -60, y0: 0, y1: 120}}
    title="Roda"
    label="Sumeria · ±3500 SM"
    pose="jalan"
    wipeIn="slideL"
    wipeOut="wheel"
  >
    <Wheel duration={duration} />
  </BeatFrame>
);
