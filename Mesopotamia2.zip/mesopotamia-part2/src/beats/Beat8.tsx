import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C, FONT} from '../theme';

// Fokus: 6 penemuan menjadi batu bata yang ditumpuk membentuk fondasi bertingkat (seperti ziggurat).
const BW = 160;
const BH = 84;
const BRICKS = [
  {t: 'Tulisan', x: 10, y: 456, at: 10},
  {t: 'Roda', x: 180, y: 456, at: 18},
  {t: 'Basis 60', x: 350, y: 456, at: 26},
  {t: 'Kalender', x: 95, y: 362, at: 46},
  {t: 'Irigasi', x: 265, y: 362, at: 54},
  {t: 'Ziggurat', x: 180, y: 268, at: 78},
];

const Bricks: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <svg width={520} height={560} viewBox="0 0 520 560">
      {BRICKS.map((b, i) => {
        const sp = spring({frame: frame - b.at, fps, config: {damping: 14, stiffness: 160}});
        const y = -320 * (1 - sp);
        const top = i === BRICKS.length - 1;
        return (
          <g key={i} transform={`translate(${b.x} ${b.y + y})`}>
            <polygon points={`4,8 60,2 ${BW - 50},6 ${BW - 4},2 ${BW},${BH / 2} ${BW - 6},${BH - 4} 70,${BH} 6,${BH - 6} 0,${BH / 2}`}
              fill={top ? C.gold : C.clayLight} stroke={C.ink} strokeWidth={6} strokeLinejoin="round" />
            <text x={BW / 2} y={BH / 2 + 10} textAnchor="middle" fontFamily={FONT} fontSize={26} fill={C.ink}>
              {b.t}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

export const Beat8: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={8}
    duration={duration}
    bg="bg8.jpg"
    cam={{s0: 1.3, s1: 1.0, x0: 0, x1: 0, y0: 100, y1: 0}}
    title="Warisan Besar"
    label="Fondasi peradaban"
    pose="belakang"
    wipeIn="zoom"
    wipeOut="black"
  >
    <Bricks />
  </BeatFrame>
);
