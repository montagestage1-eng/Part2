import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {BeatFrame, BeatProps} from '../components/BeatFrame';
import {C} from '../theme';

// Fokus: tablet tanah liat; baris tulisan baji digores satu per satu oleh stylus.
const ROWS = [95, 175, 255, 335];
const COLS = 8;

// bentuk baji deterministik: tiap glyph = 1-3 baji dengan sudut dari tabel tetap
const ANGLES = [0, 90, 45, 135, 20, 160, 70, 110];
const wedge = (x: number, y: number, ang: number, len: number) => (
  <g transform={`translate(${x} ${y}) rotate(${ang})`}>
    <polygon points={`0,-7 0,7 ${len},0`} fill={C.clayDark} />
  </g>
);

const Tablet: React.FC = () => {
  const frame = useCurrentFrame();
  const rowP = (k: number) =>
    interpolate(frame, [18 + k * 30, 18 + k * 30 + 26], [0, 1], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
      easing: Easing.linear,
    });
  const activeRow = ROWS.findIndex((_, k) => rowP(k) > 0 && rowP(k) < 1);
  return (
    <svg width={520} height={420} viewBox="0 0 520 420">
      <polygon
        points="14,30 120,10 300,20 470,8 506,40 510,200 500,380 340,408 160,400 22,396 8,300 12,150"
        fill={C.clayLight} stroke={C.ink} strokeWidth={7} strokeLinejoin="round"
      />
      <defs>
        {ROWS.map((y, k) => (
          <clipPath id={`row${k}`} key={k}>
            <rect x={0} y={y - 40} width={20 + 480 * rowP(k)} height={80} />
          </clipPath>
        ))}
      </defs>
      {ROWS.map((y, k) => (
        <g key={k} clipPath={`url(#row${k})`}>
          {Array.from({length: COLS}, (_, c) => {
            const x = 44 + c * 56;
            const a = ANGLES[(c * 3 + k * 5) % ANGLES.length];
            const b = ANGLES[(c * 5 + k * 3 + 2) % ANGLES.length];
            const n = 1 + ((c + k) % 3);
            return (
              <g key={c}>
                {wedge(x, y - 10, a, 30)}
                {n > 1 ? wedge(x + 8, y + 12, b, 26) : null}
                {n > 2 ? wedge(x + 22, y - 4, a + 90, 22) : null}
              </g>
            );
          })}
        </g>
      ))}
      {activeRow >= 0 ? (
        <g transform={`translate(${20 + 480 * rowP(activeRow)} ${ROWS[activeRow]})`}>
          <line x1={0} y1={0} x2={48} y2={-52} stroke={C.ink} strokeWidth={9} strokeLinecap="round" />
          <circle cx={0} cy={0} r={6} fill={C.gold} />
        </g>
      ) : null}
    </svg>
  );
};

export const Beat2: React.FC<BeatProps> = ({duration}) => (
  <BeatFrame
    beat={2}
    duration={duration}
    bg="bg2.jpg"
    cam={{s0: 1.0, s1: 1.3, x0: 0, x1: 120, y0: 0, y1: -130}}
    title="Tulisan Cuneiform"
    label="Uruk · ±3300 SM"
    pose="tunjuk"
    wipeIn="cap"
    wipeOut="slideL"
  >
    <Tablet />
  </BeatFrame>
);
