import type React from 'react';
import layoutJson from './layout.json';

export type Rect = {x: number; y: number; w: number; h: number};

export const W: number = layoutJson.canvas.w;
export const H: number = layoutJson.canvas.h;
export const FIXED = layoutJson.fixed as Record<'title' | 'label' | 'stickman' | 'subtitle', Rect>;
export const FOCUS = layoutJson.focus as Record<string, Rect>;
export const MOTION = layoutJson.motion;

export const rectStyle = (r: Rect): React.CSSProperties => ({
  position: 'absolute',
  left: r.x,
  top: r.y,
  width: r.w,
  height: r.h,
});
